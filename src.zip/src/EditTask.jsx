import React from 'react'

const EditTask = (handleUpdateTask, title) => {
    return (
        <form onSubmit={handleUpdateTask} className="todo-form">

            <div className="field">
                <label htmlFor="title">Title <span aria-hidden="true">*</span></label>
                <input value={formData.title} onChange={handleChange} type="text" id="title" name="title" placeholder="e.g. Buy groceries" />
            </div>

            <div className="field">
                <label htmlFor="desc">Description</label>
                <textarea value={formData.description} onChange={handleChange} id="desc" name="description" placeholder="Optional — add details like shopping list, deadline, etc." rows="4"></textarea>
            </div>

            <div className="row">
                <div className="hint">Tip: press <strong>Enter</strong> to move between fields.</div>
                <div className="actions">
                    <button type="reset" className="btn secondary">Reset</button>
                    <button type="submit" className="btn">Add Todo</button>
                </div>
            </div>

            <div id="success" className="success-msg">Todo added successfully — this is a visual demo.</div>

        </form>
    )
}

export default EditTask