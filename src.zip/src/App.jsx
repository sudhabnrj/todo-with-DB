import { useEffect, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { supabase } from './supabaseClient'

function App() {

  const [formData, setFormData] = useState({
    title: '',
    description: ''
  })

  const [isEditing, setIsEditing] = useState(false);

  const [tasks, setTasks] = useState([])

  useEffect(() => {
    fetchAllTasks();
  }, [])

  const fetchAllTasks = async () => {
    let { data: task, error } = await supabase
      .from('task')
      .select('*')
    if (error) {
      console.error("Fetch error:", error);
    } else {
      setTasks(task);
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value

    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      alert("Title is required");
      return;
    }
    const { data, error } = await supabase
      .from("task")
      .insert([{ title: formData.title, description: formData.description }]).select();
    if (error) {
      console.error("Insert error:", error);
    } else {
      alert("Todo added successfully!")
      setTasks(prev => [...prev, data[0]]);
      setFormData({ title: '', description: '' }); // reset form
    }
  }

  const handleEditTask = () => {

  }

  const handleUpdateTask = async (id) => {
    const { data: task } = await supabase.form('task').update().eq("id", id).select();
  }

  const handleDelete = async (id) => {
    const { data: task } = await supabase.from('task').delete().eq("id", id).select('*');
    fetchAllTasks();
  }

  return (
    <div className="main-content">
      <div className="container" role="region" aria-labelledby="form-title">
        <header>
          <div className="logo" aria-hidden="true">TB</div>
          <div>
            <h1 id="form-title">Add a new todo</h1>
            <p className="lead">Quickly jot down a task — title is required, description is optional.</p>
          </div>
        </header>


        {/* <!-- Accessible form with required attributes --> */}
        <form onSubmit={handleSubmit} className="todo-form">

          <div className="field">
            <label htmlFor="title">Title <span aria-hidden="true">*</span></label>
            <input value={formData.title} onChange={handleChange} type="text" id="title" name="title" placeholder="e.g. Buy groceries" />
          </div>

          <div className="field">
            <label htmlFor="desc">Description</label>
            <textarea value={formData.description} onChange={handleChange} id="desc" name="description" placeholder="Optional — add details like shopping list, deadline, etc." rows="4"></textarea>
          </div>

          <div className="row">
            <div className="hint">Tip: press <strong>Enter</strong> to move between fields.</div>
            <div className="actions">
              <button type="reset" className="btn secondary">Reset</button>
              <button type="submit" className="btn">Add Todo</button>
            </div>
          </div>

          <div id="success" className="success-msg">Todo added successfully — this is a visual demo.</div>

        </form>
      </div>

      <section className="task-list">
        <h2>Your Tasks</h2>

        <div className="tasks">
          {tasks.length === 0 ? (
            <p>No tasks found.</p>
          ) : tasks.map((task) => (
            <div key={task?.id} className="task">
              <div className="task-content">
                <h3>{task?.title}</h3>
                <p>{task.description}</p>
              </div>
              <div className="task-actions">
                <button onClick={() => handleEditTask(task?.id)} className="edit-btn" aria-label="Edit task">✎</button>
                <button onClick={() => handleDelete(task?.id)} className="delete-btn" aria-label="Delete task">✕</button>
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  )
}

export default App
